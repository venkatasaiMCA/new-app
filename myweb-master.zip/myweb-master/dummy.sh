Learning how to use git on linux
Dummy 
